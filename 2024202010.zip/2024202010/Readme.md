I have used this function in question 1 to find 2 words in a line
awk '/POST/ && /404/' access.log


I have used this function in question 2 to add all the numbers int the power level file 
awk -F',' ' {sum+=$4} END {print sum}' power_levels.txt